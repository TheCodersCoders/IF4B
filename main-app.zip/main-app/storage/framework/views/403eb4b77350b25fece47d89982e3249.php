<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Tambah Ikan</title>
    <link rel="icon" href="<?php echo e(asset('assets/img/iconfish.png')); ?>">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet"
  integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
</head>
<body>
    <div class="container">
        <h1 class="text-center mb-3">Tambah Data Ikan</h1>
        <form class="forms-sample " action="<?php echo e(route('ikan.store')); ?>" method="post" enctype="multipart/form-data"><?php echo csrf_field(); ?>
          <div class="form-group">
            <div class="mb-3 col-lg-6">
                <label  class="form-label">Nama Ikan</label>
                <input type="text" class="form-control" id="nama_ikan" placeholder="Ikan" value="<?php echo e(old('nama_ikan')); ?>" name="nama_ikan">
                <?php $__errorArgs = ['nama_ikan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <label  class="form-label">Deskripsi</label>
                <textarea type="text" class="form-control" id="deskripsi" placeholder="deskripsi" value="<?php echo e(old('deskripsi')); ?>" name="deskripsi"> </textarea>
                <?php $__errorArgs = ['deskripsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <label>Jenis Air</label>
                <br>
                <select name="air_id" id="form-control js-example-basic-single mb-3" class="form-select">
                <?php $__currentLoopData = $air; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($item->id); ?>"><?php echo e($item->jenis_air); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
              <?php $__errorArgs = ['air_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <span class="text-danger"><?php echo e($message); ?></span>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              <br>
                <label>Foto</label>
                <input type="file" class="form-control" id="foto" placeholder="Foto" name="foto" value="<?php echo e(old('foto')); ?>">                    
            <?php $__errorArgs = ['foto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
            </div>
              <button type="submit" class="btn btn-info me-2 col-lg-6">Submit</button>
            </form>
            <a href="<?php echo e(route('ikan.index')); ?>"><button class="btn btn-danger mt-2 col-lg-6">Cancel</button></a>
    </div>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous">
  </script>
</body>
</html><?php /**PATH D:\Xampp\htdocs\WebII\IF4B\main-app\resources\views/ikan/create.blade.php ENDPATH**/ ?>