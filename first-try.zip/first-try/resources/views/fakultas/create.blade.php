@extends('layout.main')
@section('title', 'Halaman Fakultas')
@section('subtitle', 'Fakultas')
@section('content')
{{-- Isi Formulir Content --}}
<h2>Tambah Fakultas</h2>
@endsection