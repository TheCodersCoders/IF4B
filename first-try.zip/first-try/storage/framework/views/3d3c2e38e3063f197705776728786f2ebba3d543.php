
<?php $__env->startSection('title', 'Tambah Data'); ?>
<?php $__env->startSection('subtitle', 'Fakultas'); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
<div class="col-md-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Tambah Fakultas</h4>
                  <p class="card-description">
                    Formulir tambah fakultas
                  </p>
                  <form class="forms-sample" action="<?php echo e(route('fakultas.store')); ?>" method="post"> <?php echo csrf_field(); ?>
                    <div class="form-group">
                      <label for="exampleInputUsername1">Nama Fakultas</label>
                      <input type="text" class="form-control" id="nama" placeholder="Nama Fakultas" name="nama_fakultas">
                      <?php $__errorArgs = ['nama_fakultas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <span class="text-danger"><?php echo e($message); ?></span>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                      <label for="exampleInputEmail1">Nama Dekan</label>
                      <input type="name" class="form-control" id="namaDekan" placeholder="Nama Dekan" name="nama_dekan">
                      <?php $__errorArgs = ['nama_dekan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <span class="text-danger"><?php echo e($message); ?></span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                      <label for="exampleInputEmail">Nama Wakil Dekan</label>
                      <input type="name" class="form-control" id="namaWakilDekan" placeholder="Wakil Dekan" name="nama_wakil">
                      <?php $__errorArgs = ['nama_wakil'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <span class="text-danger"><?php echo e($message); ?></span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-check form-check-flat form-check-primary">
                      <label class="form-check-label">
                        <input type="checkbox" class="form-check-input">
                        Remember me
                      <i class="input-helper"></i></label>
                    </div>
                    <button type="submit" class="btn btn-info me-2">Submit</button>
                    <a href="<?php echo e(route('fakultas.index')); ?>"><button class="btn btn-light">Cancel</button></a>
                  </form>
                </div>
              </div>
            </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\htdocs\WebII\IF4B\first-try\resources\views/fakultas/create.blade.php ENDPATH**/ ?>