
<?php $__env->startSection('title', 'Halaman Prodi'); ?>
<?php $__env->startSection('subtitle', 'Prodi'); ?>
<?php $__env->startSection('content'); ?>
<table class="table table-light table-striped table-active table-hover">
    <thead>
        <tr>
            <td>Nama Prodi</td>
            <td>Fakultas</td>
            <td>Created At</td>
        </tr>
    </thead>
    <?php $__currentLoopData = $prodis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tbody>
        <tr>
            <td><?php echo e($item->nama_prodi); ?></td>
            <td><?php echo e($item->fakultas->nama_fakultas); ?></td>
            <td><?php echo e($item->created_at); ?></td>
        </tr>
    </tbody>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\htdocs\WebII\IF4B\first-try\resources\views/prodi/index.blade.php ENDPATH**/ ?>