
<?php $__env->startSection('title', 'Halaman Fakultas'); ?>
<?php $__env->startSection('subtitle', 'Fakultas'); ?>
<?php $__env->startSection('content'); ?>
        <ul>
            <?php $__currentLoopData = $dataFakultas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <?php echo e($item); ?>

            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\htdocs\WebII\IF4B\first-try\resources\views/fakultas/index.blade.php ENDPATH**/ ?>