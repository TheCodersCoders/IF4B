
<?php $__env->startSection('title', 'Halaman Fakultas'); ?>
<?php $__env->startSection('subtitle', 'Fakultas'); ?>
<?php $__env->startSection('content'); ?>
<table class="table table-hover table-dark table-striped">
    <thead>
        <tr>
            <th>Nama Fakultas</th>
            <th>Nama Dekan</th>
            <th>Nama Wakil Dekan</th>
            <th>Prodi</th>
            <th>Created At</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $dataFakultas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($item->nama_fakultas); ?></td>
            <td><?php echo e($item->nama_dekan); ?></td>
            <td><?php echo e($item->nama_wakil_dekan); ?></td>
            <td>
                <?php $__currentLoopData = $item->prodi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prodi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($prodi->nama_prodi); ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                </td>
            <td><?php echo e($item->created_at); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
        </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\htdocs\WebII\IF4B\first-try\resources\views/fakultas/index.blade.php ENDPATH**/ ?>