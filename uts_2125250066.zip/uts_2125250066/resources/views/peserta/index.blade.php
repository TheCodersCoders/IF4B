@extends('layout.master')
@section('title', 'Kampus Merdeka')
@section('content')
@foreach ($dataPeserta as $item )
<div class="row col-lg-4">
<div class="card col-lg-4 col-sm-6 mt-2" style="width: 300px">
    <div class="card-header">
      Kampus Merdeka
    </div>
    <div class="card-body ">
      <img src="{{ $item->url_foto }}" class="card-img-top" alt="">
      <h5 class="card-title">{{ $item->nama }}</h5>
      <p class="card-text">{{ $item->email}}</p>
      <a href="https://mdp.ac.id/?gclid=CjwKCAjwrdmhBhBBEiwA4Hx5g5VybSNvP6bDuCBTr_ORNWCasLHpaGO2bGq3jC3W1asQYgUm-ErTUhoCjk8QAvD_BwE" style="text-decoration: none">{{$item->asal_pt }}</a>
    </div>
  </div>
</div>
@endforeach
@endsection
