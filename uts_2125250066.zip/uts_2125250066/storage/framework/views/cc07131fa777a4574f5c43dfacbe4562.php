
<?php $__env->startSection('title', 'Kampus Merdeka'); ?>
<?php $__env->startSection('content'); ?>
<?php $__currentLoopData = $dataPeserta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="row col-lg-4">
<div class="card col-lg-4 col-sm-6 mt-2" style="width: 300px">
    <div class="card-header">
      Kampus Merdeka
    </div>
    <div class="card-body ">
      <img src="<?php echo e($item->url_foto); ?>" class="card-img-top" alt="">
      <h5 class="card-title"><?php echo e($item->nama); ?></h5>
      <p class="card-text"><?php echo e($item->email); ?></p>
      <a href="https://mdp.ac.id/?gclid=CjwKCAjwrdmhBhBBEiwA4Hx5g5VybSNvP6bDuCBTr_ORNWCasLHpaGO2bGq3jC3W1asQYgUm-ErTUhoCjk8QAvD_BwE" style="text-decoration: none"><?php echo e($item->asal_pt); ?></a>
    </div>
  </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\htdocs\WebII\IF4B\uts_2125250066\resources\views/peserta/index.blade.php ENDPATH**/ ?>